import React,{ useState, FC } from 'react'
import { Popconfirm, Button, Pagination, message  } from 'antd';
import ProTable, { ProColumns } from '@ant-design/pro-table'; 
import { PageContainer } from '@ant-design/pro-layout';
import { addRecord, editRecord } from './service'
import { connect, Dispatch, Loading, UserState, TodoState  } from 'umi'
import UserModal from './components/UserModal'
import { SingleUserType, SingleTodoType, FormValue } from './data.d'

interface UserPageProps {
  users: UserState,
  todos: TodoState,
  dispatch: Dispatch,
  handleCancle: ()=>void,
  onFinish: (values: FormValue) => void,
  userListLoading: boolean,
  confirmLoading: boolean,
}



const UserListPage:FC<UserPageProps> = ({ users, todos, dispatch, userListLoading } ) => {
  const [modalVisible, setModalVisible] = useState(false)
  const [confirmLoading, setConfirmloading] = useState(false)

  const [record, setRecord] = useState<SingleUserType | null>(null)
  const [todo, setTodo] = useState<SingleTodoType | null>(null)
  
  // 关闭modal
  const handleCancle = () => {
    setModalVisible(false)
  }

  const userDelete = (record: SingleUserType) => {
    setRecord(record)
  }

  const todoDelete = (record: SingleTodoType) => {
    setTodo(todo)
  }

  // 刷新
  const resetHandler = () => {
    dispatch({
      type: 'users/getRemote',
      payload: {
        page: users.meta.page,
        per_page: users.meta.per_page
      }
    });
    dispatch({
      type: 'todos/getRemoteTodos',
      payload: {
        page: users.meta.page,
        per_page: users.meta.per_page
      }
    })
  }

  // 删除
  const confirmDelete = () => {
    const id = record && record.id
    dispatch({
      type: 'users/delete',
      payload: {
        id
      }
    })    
  }

  // 增加
  const addClick = () =>{
    setRecord(null)
    setModalVisible(true)
  }

  // 点击编辑按钮
  const userEdit = (record: SingleUserType) => {
    setModalVisible(true)
    setRecord(record)
  }

  const todoEdit = (record: SingleTodoType) => {
    setModalVisible(true)
    setTodo(record)
  }


  // 确认修改
  const onFinish = async(values: FormValue) => {
    setConfirmloading(true)
    let id = 0;
    if(record){
      id = record.id
    }

    let serviceFunc;
    if(id){
      serviceFunc = editRecord
    }else{
      serviceFunc = addRecord
    }
    const result = await serviceFunc({id, values})

    if(result){ 
      setModalVisible(false)
      setConfirmloading(false)
      message.success(`${id === 0 ? 'ADD' : 'Edit'} Success`)
      resetHandler()
    }else{
      message.error(`${id === 0 ? 'Add' : 'Edit'} Failed`)
      setConfirmloading(false)
    }

  };

  // 页码跳转
  const paginationChange = (page: number, pageSize?: number) => {
    dispatch({
      type: 'users/getRemote',
      payload:{
        page,
        per_page: pageSize ? pageSize : users.meta.per_page
      }
    })
  }

  const columns: ProColumns<SingleUserType>[] = [
      {
        title: 'ID',
        dataIndex: 'id',
        valueType: 'digit'
      },
      {
        title: 'Name',
        dataIndex: 'name',
        valueType: 'text'
      },
      {
        title: 'Create Time',
        dataIndex: 'create_time',
        valueType: 'dateTime'
      },
      {
        title: 'Action',
        valueType: 'option',
        render: (text: any, record: SingleUserType) => [
            <a key={record.id} onClick={()=>userEdit(record)}>Edit</a>,
            <Popconfirm
              key = {record.id}
              title="Are you sure delete this task?"
              onConfirm={confirmDelete}
              okText="Yes"
              cancelText="No"
            >
              <a  onClick={()=>userDelete(record)}>Delete</a>
            </Popconfirm>
        ]
      },
  ];

  const columnsTodo: ProColumns<SingleTodoType>[] = [
    {
      title: 'userId',
      dataIndex: 'userId',
      valueType: 'digit'
    },
    {
      title: 'id',
      dataIndex: 'id',
      valueType: 'digit'
    },
    {
      title: 'title',
      dataIndex: 'title',
      valueType: 'text'
    },
    {
      title: 'completed',
      dataIndex: 'completed',
      valueType: 'text'
    },
    {
      title: 'Action',
      valueType: 'option',
      render: (text: any, todo: SingleTodoType) => [
          <a key={todo.id} onClick={()=>todoEdit(todo)}>Edit</a>,
          <Popconfirm
            key = {todo.id}
            title="Are you sure delete this task?"
            onConfirm={confirmDelete}
            okText="Yes"
            cancelText="No"
          >
            <a  onClick={()=>todoDelete(todo)}>Delete</a>
          </Popconfirm>
      ]
    },
];


  return(
      <PageContainer>

          <ProTable 
            rowKey='id' 
            headerTitle="User List"
            toolBarRender={() => [
              <Button onClick={addClick}type='primary'>ADD</Button>,
              <Button onClick={resetHandler}>Reload</Button>
            ]}
            columns={columns} 
            dataSource={users.data} 
            loading={userListLoading}
            search={false}
            pagination={false}
            options={{
              density: true,
              fullScreen: true,
              reload: () => {
                resetHandler()
              },
              setting: true
            }}
          />
      
          <Pagination
            className= 'list-page'
            total={users.meta.total}
            current={users.meta.page}
            pageSize = {users.meta.per_page}
            pageSizeOptions={['5', '10', '15', '20']}
            showSizeChanger
            showQuickJumper
            showTotal={total => `Total ${total} items`}
            onChange = { paginationChange }
          />


      <ProTable 
            rowKey='id' 
            headerTitle="Todo List"
            toolBarRender={() => [
              <Button onClick={addClick}type='primary'>ADD</Button>,
              <Button onClick={resetHandler}>Reload</Button>
            ]}
            columns={columns} 
            dataSource={users.data}  
            loading={userListLoading}
            search={false}
            pagination={false}
            options={{
              density: true,
              fullScreen: true,
              reload: () => {
                resetHandler()
              },
              setting: true
            }}
          />    
        
          <UserModal 
            visible={modalVisible} 
            handleCancle={handleCancle} 
            record={record}
            onFinish={onFinish}
            confirmLoading={confirmLoading}
          />  

      </PageContainer>
  )
}

const mapStateToProps = ({users, todos, loading }: {users: UserState, todos: TodoState, loading: Loading}) => {
  return {
    users,
    todos,
    userListLoadin: loading.models.users
  }
}
export default connect(mapStateToProps)(UserListPage)