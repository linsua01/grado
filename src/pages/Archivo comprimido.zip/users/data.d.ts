export interface SingleUserType {
  id: number,
  name: string,
  email: string,
  create_time: string,
  update_time: string,
  status: 1
}

export interface SingleTodoType {
  userId: number,
  id: number,
  title: string,
  completed: boolean
}

export interface FormValue {
  [name: string]: any
}