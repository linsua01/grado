import { Reducer, Effect, Subscription } from 'umi';
import { getRemoteTodo, editTodo, deleteTodo, addTodo } from './service'
import { message } from 'antd';
import { SingleTodoType } from './data'

export interface TodoState {
  data: SingleTodoType[],
  meta: {
    total: number,
    per_page: number,
    page: number
  }
}

interface TodoModelType {
  namespace: 'todos',
  state: TodoState,
  reducers: {
    getTodos: Reducer<TodoState>
  },
  effects: {
    getAll: Effect,
    deleteTodo: Effect,
  },
  subscriptions: {
    setupTodo: Subscription
  }
}

export const TodoModel: TodoModelType = {
  namespace: 'todos',
  state: {
    data: [],
    meta: {
      total: 0,
      per_page: 20,
      page: 0
    }
  },
  reducers: {
    getTodos(state, action){
      return action.payload  
    }
  },
  effects: {
    // 获取列表数据
    *getAll({ payload: { page, per_page }}, {put, call}){
      const data = yield call(getRemoteTodo, { page, per_page })
      if(data){
        yield put({
          type: 'getTodos',
          payload: {
            data: data,
            meta: {
              total: 1,
              per_page: 20,
              page: 0 
            }
          }
        })
      }
      
    },
  
    // 删除
    *deleteTodo({payload:{id}}, { put, call, select }){

      const data = yield call(deleteTodo,{ id })
  
      if(data){
        const {page, per_page} = yield select((state: any) => state.users.meta)
        yield put({
          type: 'getRemoteTodos',
          payload: {
            page,
            per_page
          }
        })
        message.success('Delete Success')
      }else{
        message.error('Delete Error')
      }
    },
  },
  
  subscriptions: {
    setupTodo({ dispatch, history }, done){
      return history.listen(({pathname}) => {
        // console.log('subscriptions')
        if(pathname === '/apitodos'){
          dispatch({
            type: 'getTodos',
            payload: {
              page: 1,
              per_page: 5
            }
          })
        }
      })
    }
  }

}

export default TodoModel 
