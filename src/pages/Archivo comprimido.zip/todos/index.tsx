import React,{ useState, FC } from 'react'
import { Popconfirm, Button, Pagination, message  } from 'antd';
import ProTable, { ProColumns } from '@ant-design/pro-table'; 
import { PageContainer } from '@ant-design/pro-layout';

import { addTodo, editTodo } from './service'

import { connect, Dispatch, Loading, TodoState  } from 'umi'
//import UserModal from './components/UserModal'
import { SingleTodoType, FormValue } from './data.d'

interface TodoPageProps {
  todos: TodoState,
  dispatch: Dispatch,
  handleCancle: ()=>void,
  onFinish: (values: FormValue) => void,
  todoListLoading: boolean,
  confirmLoading: boolean,
}



const TodoListPage:FC<TodoPageProps> = ({todos, dispatch, todoListLoading } ) => {

  const [modalVisible, setModalVisible] = useState(false)
  const [confirmLoading, setConfirmloading] = useState(false)

  const [todo, setTodo] = useState<SingleTodoType | null>(null)
  
  // modal
  const handleCancle = () => {
    setModalVisible(false)
  }

  const todoDelete = (record: SingleTodoType) => {
    setTodo(todo)
  }

  // 刷新
  const resetHandler = () => {
    dispatch({
      type: 'todos/getAll',
      payload: {
        page: todos.meta.page,
        per_page: todos.meta.per_page
      }
    })
  }

  const test = () => {
    dispatch({
      type: 'todos/test!',
      payload: {
        page: todos.meta.page,
        per_page: todos.meta.per_page
      }
    })
  }


  // 删除
  const todoDeleteConfirm = () => {
    const id = todo && todo.id
    dispatch({
      type: 'todo/delete',
      payload: {
        id
      }
    })    
  }

  // 增加
  const todoAdd = () =>{
    setTodo(null)
    setModalVisible(true)
  }

  const todoEdit = (record: SingleTodoType) => {
    setModalVisible(true)
    setTodo(record)
  }


  // 确认修改
  const onFinish = async(values: FormValue) => {
    setConfirmloading(true)
    let id = 0;
    if(todo){
      id = todo.id
    }

    let serviceFunc;
    if(id){
      serviceFunc = todoEdit
    }else{
      serviceFunc = todoAdd
    }
    //const result = await serviceFunc({id, values})

    if(true){ 
      setModalVisible(false)
      setConfirmloading(false)
      message.success(`${id === 0 ? 'add' : 'Edit'} Success`)
      resetHandler()
    }else{
      message.error(`${id === 0 ? 'Add' : 'Edit'} Failed`)
      setConfirmloading(false)
    }

  };

  // 页码跳转
  const paginationChange = (page: number, pageSize?: number) => {
    dispatch({
      type: 'todo/getRemote',
      payload:{
        page,
        per_page: pageSize ? pageSize : todos.meta.per_page
      }
    })
  }

  const columns: ProColumns<SingleTodoType>[] = [
    {
      title: 'userId',
      dataIndex: 'userId',
      valueType: 'digit'
    },
    {
      title: 'id',
      dataIndex: 'id',
      valueType: 'digit'
    },
    {
      title: 'title',
      dataIndex: 'title',
      valueType: 'text'
    },
    {
      title: 'completed',
      dataIndex: 'completed',
      valueType: 'text'
    },
    {
      title: 'Action',
      valueType: 'option',
      render: (text: any, todo: SingleTodoType) => [
          <a key={todo.id} onClick={()=>todoEdit(todo)}>Edit</a>,
          <Popconfirm
            key = {todo.id}
            title="Are you sure delete this task?"
            onConfirm={todoDeleteConfirm}
            okText="Yes"
            cancelText="No"
          >
            <a  onClick={()=>todoDelete(todo)}>Delete</a>
          </Popconfirm>
      ]
    },
];


  return(
      <PageContainer>

          <ProTable 
            rowKey='id' 
            headerTitle="Todo List"
            toolBarRender={() => [
              <Button onClick={todoAdd}type='primary'>New</Button>,
              <Button onClick={test}type='default'>Test</Button>
            ]}
            columns={columns} 
            dataSource={todos.data} 
            loading={todoListLoading}
            search={false}
            pagination={false}
            options={{
              density: true,
              fullScreen: true,
              reload: () => {
                resetHandler()
              },
              setting: true
            }}
          />
      
          <Pagination
            className= 'list-page'
            total={10}
            current={1}
            pageSize = {1}
            pageSizeOptions={['5', '10', '15', '20']}
            showSizeChanger
            showQuickJumper
            showTotal={total => `Total ${1} items`}
            onChange = { paginationChange }
          />

      </PageContainer>
  )
}

const mapStateToProps = ({todos, loading }: {todos: TodoState, loading: Loading}) => {
  return {
    todos,
    TodoListLoadin: loading.models.todos
  }
}
export default connect(mapStateToProps)(TodoListPage)