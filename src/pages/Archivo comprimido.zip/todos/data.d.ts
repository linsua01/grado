
export interface SingleTodoType {
  userId: number,
  id: number,
  title: string,
  completed: boolean
}

export interface FormValue {
  [title: string]: any
}