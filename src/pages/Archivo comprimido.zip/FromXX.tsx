import React from 'react';
import { message, Button } from 'antd';
import ProForm, {
    ProFormText ,
    ProFormDateRangePicker ,
    ProFormSelect ,
  } from '@ant-design/pro-form';

  import ProDescriptions from '@ant-design/pro-descriptions';

export default FromXX => (
    <>
<ProForm

      onFinish={async (values) => {
        //await waitTime(2000);
        console.log(values);
        message.success('Enviado satisfactoriamente!');
      }}
    >
      <ProForm.Group>
        <ProFormText
          name="name"
          label="Nombre de Cliente"
          tooltip="Hasta 24 dígitos"
          placeholder="Por favor ingrese un nombre"
        />
        <ProFormText 
            name="company" 
            label="Nombre de Empresa" 
            placeholder="Por favor ingrese un nombre" />
      </ProForm.Group>

      <ProForm.Group>
        <ProFormText 
            name="contract" 
            label="Título del contrato" 
            placeholder="Título del contrato" />

        <ProFormDateRangePicker 
            name="contractTime" 
            label="Tiempo de vigencia del contrato" />
      </ProForm.Group>
      
      <ProForm.Group>
        <ProFormSelect
          options={[
            {
              value: 'chapter',
              label: 'Efectivo después de estampar',
            },
          ]}
          width="s"
          name="useMode"
          label="Forma efectiva de contratación"
        />
        <ProFormSelect
          options={[
            {
              value: 'time',
              label: 'Terminación después del cumplimiento',
            },
          ]}
          width="xs"
          name="unusedMode"
          label="Invalidación contractual"
        />
      </ProForm.Group>

      <ProFormText 
        width="s" 
        name="id" 
        label="Número de contrato principal" />

      <ProFormText 
        name="project" 
        disabled 
        label="Nombre del Proyecto" 
        initialValue="P00-1" />

      <ProFormText 
        width="xs" 
        name="mangerName" 
        disabled 
        label="Gerente de Negocios" 
        initialValue="G00-1" />
    </ProForm>

<ProDescriptions
title="request"
request={async () => {
  return Promise.resolve({
    success: true,
    data: { Lu: '51', date: '20200730', money: '12121' },
  });
}}
extra={<Button type="link">Edit</Button>}
>
<ProDescriptions.Item label="Lu" dataIndex="Lu" />
<ProDescriptions.Item dataIndex="date" label="Date" valueType="date" />
<ProDescriptions.Item label="Money" dataIndex="money" valueType="money" />

<ProDescriptions.Item label="Text" valueType="option">
  <Button type="primary">Sent</Button>
  <Button>Restart</Button>
</ProDescriptions.Item>
</ProDescriptions>

</>

);