import React from 'react';
import PropTypes from 'prop-types';
import {connect, Dispatch, Loading} from 'umi';

//import SearchBar from '../../components/SearchBar/SearchBar';
//import SearchForm from '../../components/SearchForm/SearchForm';
//import CustomerList from '../../components/Customers/CustomerList/CustomerList';
//import {routerRedux} from 'dva/router';
//import BreadcrumbList from '../../components/BreadcrumbList/BreadcrumbList';
//import Customer from '../../components/Customers/AddCustomer/AddCustomer';
//import {redirect} from '../../utils/webSessionUtils';
//import {customerClass, customerContainer, addCustomerContainer, modifyCustomerContainer} from './index.css';
import { queryAll } from './service';
import { PageContainer, FooterToolbar } from '@ant-design/pro-layout';
import { Button, Divider, message, Input, Drawer } from 'antd';



export const index = () => {
    return (
        <div>
            <PageContainer>
                <Button type="primary">Primary Button</Button>
            </PageContainer>
        </div>
    )
}

index.propTypes = {
    customers: PropTypes.object,
}

function mapStateToProps({}) {
    return {};
}

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(index)
