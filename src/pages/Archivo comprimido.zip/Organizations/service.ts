import axios from 'axios';
import { OrganizationItem } from './data';

//const token = localStorage.getItem('token');
//const axiosHeaders = { headers: { 'Authorization': `Token  ${token}` }};
const baseURL = 'http://localhost:1337/';

export const apiGet = async () => {
   return await axios.get(`${baseURL} organizations/`)
    .then(res => res.data)
    .catch(err => err);
};

export async function apiDelete(id: number) {
  return await axios.delete(`${baseURL} organizations/${id}/`)
      .then(res => {
        return res.data
      }).catch(err =>
        {return err})
}

export async function apiAdd(item: OrganizationItem) {
  return await axios.post(`${baseURL} organizations/`, item)
      .then(res => {
        return res.data
      }).catch(err =>
        {return err})
}

export async function apiEdit(item: OrganizationItem) {
  return await axios.patch(`${baseURL} organizations/${item.id}/`, item)
      .then(res => {
        return res.data
      }).catch(err =>
        {return err})
}


