export interface OrganizationItem {
    id: number,
    name: string,
    description: string,
    published_at: string,
    created_at: string,
    updated_at: string, 
}

export interface OrganizationPagination {
  total: number;
  pageSize: number;
  currentPage: number;
}

export interface OrganizationTable {
  data: OrganizationItem[];
  pagination: Partial<OrganizationPagination>;
}

export interface OrganizationParams {
  status?: string;
  name?: string;
  desc?: string;
  key?: number;
  pageSize?: number;
  currentPage?: number;
  filter?: { [key: string]: any[] };
  sorter?: { [key: string]: any };
}
