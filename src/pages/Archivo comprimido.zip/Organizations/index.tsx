import React, {useState, useRef, useEffect, FC} from 'react';
// ant & ant-pro
import {PlusOutlined} from '@ant-design/icons';
import {PageContainer, FooterToolbar} from '@ant-design/pro-layout';
import ProTable, {ProColumns, ActionType,} from '@ant-design/pro-table';
import {Popconfirm, Button, message} from 'antd';
// services
import {connect, Dispatch, Loading, OrganizationsState} from 'umi';
import {apiAdd, apiDelete, apiEdit} from './service';

// modals
//import CreateForm from './components/CreateForm';
//import UpdateForm from './components/UpdateForm';

// interfaces
import { OrganizationItem } from './data'

// local interfaces
interface OrganizationPageProps {
  organization: OrganizationsState,
  dispatch: Dispatch,
  handleCancel: () => void,
  // onFinish: (values: FormValue) => void,
  todoListLoading: boolean,
  confirmLoading: boolean,
}

/**
 * Update func.
 * @param fields
 */
const handleUpdate = async (fields: any) => {
  const hide = message.loading('Editando');
  try {
    await apiEdit({...fields});
    hide();
    message.success('Edicion exitosa');
    return true;
  } catch (error) {
    hide();
    message.error('Edicion fallida, intenta nuevamente！');
    return false;
  }
};

/**
 *  Delete func.
 * @param selectedRows
 */



const TableExchange: FC<OrganizationPageProps> = ({organization, dispatch}) => {
  
  const [createModalVisible, handleModalVisible] = useState<boolean>(false);
  const [updateModalVisible, handleUpdateModalVisible] = useState<boolean>(false);
  
  const actionRef = useRef<ActionType>();

  const [row, setRow] = useState<OrganizationItem>();
  const [selectedRowsState, setSelectedRows] = useState<OrganizationItem[]>([]);

  const resetHandler = () => {
    dispatch({
      type: 'organizations/get',
      payload: {
        currentPage: organization.meta.currentPage,
        pageSize: organization.meta.pageSize
      }
    })
  };
  // hooks
  useEffect(() => {
    resetHandler();
  }, []);
  /**
   * 添加节点
   * @param fields
   */
  const handleAdd = async (fields: ExchangeItem) => {
    const hide = message.loading('Adding');
    try {
      await queryAdd({...fields});
      hide();
      message.success('Creación exitosa');
      return true;
    } catch (error) {
      hide();
      message.error('Falló la creación, intenta nuevamente!');
      return false;
    }
  };
  const exchangeDelete = (i: ExchangeItem) => {
    setRow(i)
  }
  const todoDeleteConfirm = () => {
    const id = row && row.id;
    dispatch({
      type: 'exchanges/delete',
      payload: {
        id
      }
    })
  };
  // edit
  let columnsEdit: ProColumns[] = [
    {
      title: 'id',
      dataIndex: 'id',
      tip: 'This is the ID',
      hideInForm: false,
      initialValue: '',
      key: 'id',
      fieldProps: {disabled: true}
    },
    {
      title: 'Nombre',
      dataIndex: 'name',
      sorter: true,
      hideInForm: false,
      initialValue: 'name',
      valueType: 'text',
      renderText: (val: string) => `${val}`,
    },
    {
      title: 'Descripción',
      dataIndex: 'description',
      hideInForm: false,
      initialValue: '',
      valueType: 'text',
    },
    {
      title: 'Slug',
      dataIndex: 'slug_name',
      hideInForm: false,
      valueType: 'text',
      initialValue: '',
    }
  ];
  const [stepFormValues, setStepFormValues] = useState([...columnsEdit]);
  const exchangeEdit = (i: ExchangeItem) => {
    for (const key in i) {
      columnsEdit = columnsEdit.map((elem) => {
        const retObj = {...elem};
        if (elem.dataIndex === key) {
          retObj.initialValue = i[key]
        }
        return retObj;
      })
    }
    setStepFormValues(columnsEdit);
    handleUpdateModalVisible(true);
  };
  const columns: ProColumns[] = [
    {
      title: 'Id',
      dataIndex: 'id',
      tip: 'This is the ID',
      hideInForm: true,
      key: 'id',
    },
    {
      title: 'Nombre',
      dataIndex: 'name',
      sorter: true,
      renderText: (val: string) => `${val}`,
      key: 'name',
      filters: [
        { text: 'London', value: 'London' },
        { text: 'New York', value: 'New York' },
      ],
      //filteredValue: filteredInfo.address || null,
      onFilter: (value, record) => record.name.includes(value),
    },
    {
      title: 'description',
      dataIndex: 'description',
      hideInForm: false,
    },
    {
      title: 'Slug',
      dataIndex: 'slug_name',
      hideInForm: false,
    },
    {
      title: 'Acción',
      valueType: 'option',
      render: (text: any, exchange: ExchangeItem) => [
        <a key={exchange.id}
           onClick={() => exchangeEdit(exchange)}>
          Editar
        </a>,
        <a>|</a>,
        <Popconfirm
          key={exchange.id}
          title="Are you sure delete this Exchange?"
          onConfirm={todoDeleteConfirm}
          okText="Yes"
          cancelText="No"
        >
          <a onClick={() => exchangeDelete(exchange)}>Eliminar</a>
        </Popconfirm>
      ]
    },
  ];
  return (
    <PageContainer>
    
      <ProTable
        headerTitle="Exchanges"
        actionRef={actionRef}
        rowKey='id'
        key="exch_id"
        search={{
          labelWidth: 120,
        }}
        toolBarRender={() => [
          <Button type="primary" key="button_key" onClick={() => handleModalVisible(true)}><PlusOutlined/>Nuevo</Button>
        ]}
        columns={columns}
        dataSource={exchanges.data}
        rowSelection={{
          onChange: (_, selectedRows) => setSelectedRows(selectedRows),
        }}
        options={{
          density: true,
          fullScreen: true,
          reload: () => {
            resetHandler()
          },
          setting: true
        }}
      />
      {selectedRowsState?.length > 0 && (
        <FooterToolbar
          extra={
            <div>
              Selection <a style={{fontWeight: 600}}>{selectedRowsState.length}</a> items
            </div>
          }>
          <Button
            onClick={async () => {
              await handleRemove(selectedRowsState);
              setSelectedRows([]);
              actionRef.current?.reloadAndRest?.();
            }}
          >
            batch deletion
          </Button>
          <Button type="primary">Batch approval</Button>
        </FooterToolbar>

      )}

      <CreateForm
        onCancel={() => handleModalVisible(false)}
        modalVisible={createModalVisible}>
        <ProTable<ExchangeItem, ExchangeItem>
          onSubmit={async (value) => {
            const success = await handleAdd(value);
            if (success) {
              handleModalVisible(false);
              resetHandler();
              if (actionRef.current) {
                actionRef.current.reload();
              }
            }
          }}
          rowKey='id'
          type="form"
          columns={columns}
        />
      </CreateForm>
      <UpdateForm
        updateModalVisible={updateModalVisible}
        onCancel={() => {
          handleUpdateModalVisible(false);
          setStepFormValues([]);
        }}
      >
        <div>
          <ProTable<ExchangeItem, ExchangeItem>
            onSubmit={async (value) => {
              const success = await handleUpdate(value);
              if (success) {
                handleUpdateModalVisible(false);
                resetHandler();
                if (actionRef.current) {
                  actionRef.current.reload();
                }
              }
            }}
            rowKey='id'
            type="form"
            columns={stepFormValues}
          />
        </div>

      </UpdateForm>

     
    </PageContainer>
  );
};

// redux
const mapStateToProps = ({exchanges, loading}: { exchanges: ExchangesState, loading: Loading }) => {
  return {
    exchanges,
    ExchangesListLoadin: loading.models.exchanges
  }
}
export default connect(mapStateToProps)(TableExchange)
