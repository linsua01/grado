import { Reducer, Effect, Subscription } from 'umi';
import { apiGet, apiEdit, apiDelete } from './service'
import { message } from 'antd';
import { OrganizationItem } from './data'

export interface OrganizationsState {
  data: OrganizationItem[],
  meta: {
    total: number,
    pageSize: number,
    currentPage: number,
  }
}

interface OrganizationsModelType {
  namespace: 'organizations',
  state: OrganizationsState,
  reducers: {
    get: Reducer<OrganizationsState>
  },
  effects: {
    getAll: Effect,
    editOne: Effect,
    deleteOne: Effect,
  },
  subscriptions: {
    setup: Subscription
  }
}


export const OrganizationsModel: OrganizationsModelType = {
  namespace: 'organizations',
  state: {
    data: [],
    meta: {
      total: 0,
      pageSize: 1,
      currentPage: 1,
    }
  },

  reducers: {
    get(state, action){
      return action.payload
    }
  },

  effects: {
    *getAll({ payload: { currentPage, pageSize }}, {put, call}){
      const data = yield call(apiGet, { currentPage, pageSize })
      if(data){
        yield put({
          type: 'get',
          payload: {
            data: data,
            meta: {
              total: 0,
              pageSize: 1,
              currentPage: 1,
            }
          }
        })
      }

    },
    *editOne({payload:{id}, onSuccess, onError }, { put, call, select }){
      const data = yield call(apiEdit, id)
      try {
        yield call(apiEdit, id)
        onSuccess('add success : )')
        yield put({ type: 'hideModal' })
      } catch (error) {
        onError(error.message)
      }
      if(data){
        yield put({
          type: 'getExchange',
          payload: {
            data: data.results,
            meta: {
              total: 1,
              per_page: 20,
              page: 0
            }
          }
        })
        message.success('Delete Success')
      }else{
        message.error('Delete Error')
      }
    },
    // 删除
    *deleteOne({payload:{id}}, { put, call, select }){
      const data = yield call(apiDelete, id )
      if(data){
        yield put({
          type: 'getExchange',
          payload: {
            data: data.results,
            meta: {
              total: 1,
              per_page: 20,
              page: 0
            }
          }
        })
        message.success('Delete Success')
      }else{
        message.error('Delete Error')
      }
    },
  },

  subscriptions: {
    setup({ dispatch, history }, done){
      return history.listen(({pathname}) => {
        // console.log('subscriptions')
        if(pathname === '/apitodos'){
          dispatch({
            type: 'getTodos',
            payload: {
              page: 1,
              per_page: 100
            }
          })
        }
      })
    }
  }

}

export default OrganizationsModel
