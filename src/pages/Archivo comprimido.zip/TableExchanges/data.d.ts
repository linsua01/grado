export interface ExchangeItem {
    id: number,
    name: string,
    description: string,
    slug_name: string,
    created_at: string, // database property
    modified_at: string,  // database property
}

export interface FormValue {
  [name: string]: any
}

export interface ExchangePagination {
  total: number;
  pageSize: number;
  currentPage: number;
}

export interface ExchangeTable {
  data: ExchangeItem[];
  pagination: Partial<ExchangePagination>;
}

export interface ExchangeParams {
  status?: string;
  name?: string;
  desc?: string;
  key?: number;
  pageSize?: number;
  currentPage?: number;
  filter?: { [key: string]: any[] };
  sorter?: { [key: string]: any };
}
