import { Reducer, Effect, Subscription } from 'umi';
import { queryAllExchanges, queryEdit, queryDelete } from './service'
import { message } from 'antd';
import { ExchangeItem } from './data'

export interface ExchangesState {
  data: ExchangeItem[],
  meta: {
    total: number,
    per_page: number,
    page: number
  }
}

interface ExchangesModelType {
  namespace: 'exchanges',
  state: ExchangesState,
  reducers: {
    getExchange: Reducer<ExchangesState>
  },
  effects: {
    getAll: Effect,
    editOne: Effect,
    delete: Effect,
  },
  subscriptions: {
    setupExchange: Subscription
  }
}

export const ExchangesModel: ExchangesModelType = {
  namespace: 'exchanges',
  state: {
    data: [],
    meta: {
      total: 0,
      per_page: 20,
      page: 1
    }
  },
  reducers: {
    getExchange(state, action){
      return action.payload
    }
  },
  effects: {
    // 获取列表数据
    *getAll({ payload: { page, per_page }}, {put, call}){
      const data = yield call(queryAllExchanges, { page, per_page })
      if(data){
        yield put({
          type: 'getExchange',
          payload: {
            data: data.results,
            meta: {
              total: 1,
              per_page: 20,
              page: 0
            }
          }
        })
      }

    },
    *editOne({payload:{id}, onSuccess, onError }, { put, call, select }){
      const data = yield call(queryEdit, id)
      try {
        yield call(queryEdit, id)
        onSuccess('add success : )')
        yield put({ type: 'hideModal' })
      } catch (error) {
        onError(error.message)
      }
      if(data){
        yield put({
          type: 'getExchange',
          payload: {
            data: data.results,
            meta: {
              total: 1,
              per_page: 20,
              page: 0
            }
          }
        })
        message.success('Delete Success')
      }else{
        message.error('Delete Error')
      }
    },
    // 删除
    *delete({payload:{id}}, { put, call, select }){
      const data = yield call(queryDelete, id )
      if(data){
        yield put({
          type: 'getExchange',
          payload: {
            data: data.results,
            meta: {
              total: 1,
              per_page: 20,
              page: 0
            }
          }
        })
        message.success('Delete Success')
      }else{
        message.error('Delete Error')
      }
    },
  },

  subscriptions: {
    setupExchange({ dispatch, history }, done){
      return history.listen(({pathname}) => {
        // console.log('subscriptions')
        if(pathname === '/apitodos'){
          dispatch({
            type: 'getTodos',
            payload: {
              page: 1,
              per_page: 100
            }
          })
        }
      })
    }
  }

}

export default ExchangesModel
