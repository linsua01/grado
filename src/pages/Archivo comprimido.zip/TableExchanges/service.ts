import axios from 'axios';
import { ExchangeItem } from './data.d';

const token = localStorage.getItem('token');
const axiosHeaders = { headers: { 'Authorization': `Token  ${token}` }};
const baseURL = 'https://thmxluis.xyz/';

export const queryAllExchanges = async () => {
   return await axios.get(`${baseURL}exchanges/`, axiosHeaders)
    .then(res => res.data)
    .catch(err => err);
};

export async function queryDelete(id: number) {
  return await axios.delete(`${baseURL}exchanges/${id}/`, axiosHeaders )
      .then(res => {
        return res.data
      }).catch(err =>
        {return err})
}

export async function queryAdd(item: ExchangeItem) {
  return await axios.post(`${baseURL}exchanges/`, item, axiosHeaders )
      .then(res => {
        return res.data
      }).catch(err =>
        {return err})
}

export async function queryEdit(item: any) {
  return await axios.patch(`${baseURL}exchanges/${item.id}/`, item, axiosHeaders )
      .then(res => {
        return res.data
      }).catch(err =>
        {return err})
}


