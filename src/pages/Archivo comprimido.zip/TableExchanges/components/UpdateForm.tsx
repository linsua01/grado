import React from 'react';
import {Modal} from 'antd';

export interface UpdateFormProps {
  onCancel: () => void;
  updateModalVisible: boolean;
}

const UpdateForm: React.FC<UpdateFormProps> = (props) => {
  const {
    onCancel,
    updateModalVisible,
  } = props;
  return (
    <Modal
      destroyOnClose
      title="Edit"
      visible={updateModalVisible}
      footer={null}
      onCancel={() => onCancel()}
    >
    {props.children}
    </Modal>
  );
};

export default UpdateForm;
