import { request } from 'umi';

const token = localStorage.getItem('token');
interface Exchange {
    id: number;
    created_at: string;
    modified_at: string;
    name: string;
    slug_name: string;
    description: string;
}

export async function queryAllExchanges() {
  return request<Exchange>('https://thmxluis.xyz/exchanges/', {
    headers: {
      Authorization: `Token ${token}`
    }
  });
}
